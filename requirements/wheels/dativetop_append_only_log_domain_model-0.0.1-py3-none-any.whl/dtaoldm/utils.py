from uuid import uuid4


def get_uuid():
    return str(uuid4())
